# University Academic System — Entity Relationship Diagram

```mermaid
erDiagram
    DEPARTMENT ||--o{ COURSE : offers
    DEPARTMENT ||--o{ LECTURER : employs
    DEPARTMENT ||--o{ STUDENT : enrolls
    DEPARTMENT o|--o| LECTURER : "has head"

    STUDENT ||--|| STUDENT_PROFILE : has
    STUDENT ||--o{ REGISTRATION : registers
    COURSE ||--o{ REGISTRATION : includes
    LECTURER }o--o{ COURSE : teaches

    DEPARTMENT {
        Long id PK
        String name UK
        String code UK
        Long head_lecturer_id FK
    }

    COURSE {
        Long id PK
        String code UK
        String title
        int credits
        String description
        Long department_id FK
    }

    LECTURER {
        Long id PK
        String first_name
        String last_name
        String email UK
        String phone
        Long department_id FK
    }

    STUDENT {
        Long id PK
        String registration_number UK
        String first_name
        String last_name
        String email UK
        Long department_id FK
    }

    STUDENT_PROFILE {
        Long id PK
        LocalDate date_of_birth
        Gender gender
        String phone_number
        String address
        Long student_id FK,UK
    }

    REGISTRATION {
        Long id PK
        Long student_id FK
        Long course_id FK
        LocalDate registration_date
        String academic_year
        String semester
        RegistrationStatus status
        Double grade
    }
```

`LECTURER` and `COURSE` are connected through the `lecturer_courses` join table.
`REGISTRATION` connects students and courses while storing enrollment details.
The student/course/year/semester combination is unique.
