# Read Me First
The following was discovered as part of building this project:

* The original package name 'com.auca.university-academic-system' is invalid and this project uses 'com.auca.university_academic_system' instead.

# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/4.1.2/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.1.2/maven-plugin/build-image.html)
* [Spring Data JPA](https://docs.spring.io/spring-boot/4.1.2/reference/data/sql.html#data.sql.jpa-and-spring-data)
* [Spring Web](https://docs.spring.io/spring-boot/4.1.2/reference/web/servlet.html)

### Guides
The following guides illustrate how to use some features concretely:

* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)

### PostgreSQL setup

The application uses PostgreSQL at `localhost:5432` by default. Create the database
before starting the application:

```sql
CREATE DATABASE university_academic_db;
```

Set the database password in the environment rather than storing credentials in
`application.properties`. In PowerShell, for example:

```powershell
$env:DB_PASSWORD = "your-postgres-password"
.\mvnw.cmd spring-boot:run
```

The database username defaults to `postgres`. Override it or the connection URL
with `DB_USERNAME` and `DB_URL` if your PostgreSQL setup differs. Hibernate's
`ddl-auto=update` creates or updates tables from the JPA entities when the
application starts; use a migration tool for production schema changes.

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.
