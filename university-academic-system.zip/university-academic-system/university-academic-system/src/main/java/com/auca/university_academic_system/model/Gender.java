package com.auca.university_academic_system.model;

public enum Gender {MALE, FEMALE}
