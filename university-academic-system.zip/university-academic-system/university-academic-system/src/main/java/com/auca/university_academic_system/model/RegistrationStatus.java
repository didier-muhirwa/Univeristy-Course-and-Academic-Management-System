package com.auca.university_academic_system.model;

public enum RegistrationStatus {
    PENDING,
    APPROVED,
    REJECTED
    
}
